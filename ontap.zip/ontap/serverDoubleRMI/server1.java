package org.example.ontapkiemtracuoiki.serverDoubleRMI;

public class server1 {
}
